def check_catch(hook, fish):
    """Task 1: a catch needs real rectangle overlap (x AND y), not just depth."""
    if fish.hooked:
        return False
    return hook.rect.colliderect(fish.rect)
