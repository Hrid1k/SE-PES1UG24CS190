import pygame

SKY = (135, 206, 235)
WATER = (20, 90, 160)
BOAT = (120, 70, 30)
WHITE = (255, 255, 255)


class Renderer:
    def __init__(self, screen, water_y):
        self.screen = screen
        self.water_y = water_y
        self.font = pygame.font.SysFont(None, 32)
        self.big = pygame.font.SysFont(None, 72)

    def _text(self, text, font, color, center=None, topleft=None, topright=None):
        img = font.render(text, True, color)
        r = img.get_rect()
        if center: r.center = center
        if topleft: r.topleft = topleft
        if topright: r.topright = topright
        self.screen.blit(img, r)

    def draw_fish(self, fish):
        r = fish.rect
        pygame.draw.ellipse(self.screen, fish.color, r)
        tail_w = max(6, r.width // 4)
        if fish.direction > 0:      # facing right, tail on the left
            tail = [(r.left, r.centery), (r.left - tail_w, r.top), (r.left - tail_w, r.bottom)]
            eye = (r.right - 7, r.centery - 2)
        else:
            tail = [(r.right, r.centery), (r.right + tail_w, r.top), (r.right + tail_w, r.bottom)]
            eye = (r.left + 7, r.centery - 2)
        pygame.draw.polygon(self.screen, fish.color, tail)
        pygame.draw.circle(self.screen, (0, 0, 0), eye, 2)

    def draw(self, hook, fishes, score, time_left, game_over, width, height):
        self.screen.fill(SKY)
        pygame.draw.rect(self.screen, WATER, (0, self.water_y, width, height - self.water_y))

        # boat + line + hook
        pygame.draw.rect(self.screen, BOAT, (hook.x - 50, self.water_y - 20, 100, 24), border_radius=6)
        pygame.draw.line(self.screen, WHITE, (hook.x, self.water_y - 20), (hook.x, hook.y), 2)
        pygame.draw.rect(self.screen, (200, 200, 200), hook.rect)

        for f in fishes:
            self.draw_fish(f)

        # HUD
        self._text(f"Score: {score}", self.font, (0, 0, 0), topleft=(12, 10))
        color = (200, 0, 0) if time_left <= 5 else (0, 0, 0)
        self._text(f"Time: {int(time_left) + (1 if time_left % 1 else 0)}", self.font, color, topright=(width - 12, 10))
        if not game_over:
            self._text("SPACE: cast", self.font, (0, 0, 0), topleft=(12, 40))

        # Task 4: end-of-round screen
        if game_over:
            overlay = pygame.Surface((width, height), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 150))
            self.screen.blit(overlay, (0, 0))
            self._text("TIME'S UP!", self.big, WHITE, center=(width // 2, height // 2 - 60))
            self._text(f"Final Score: {score}", self.big, (255, 215, 0), center=(width // 2, height // 2 + 10))
            self._text("Press R to play again", self.font, WHITE, center=(width // 2, height // 2 + 80))

        pygame.display.flip()
