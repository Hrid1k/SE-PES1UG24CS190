import pygame


class Hook:
    IDLE = "idle"
    CASTING = "casting"
    RETRACTING = "retracting"

    WIDTH = 10
    HEIGHT = 14

    def __init__(self, x, surface_y, max_depth, speed=300):
        self.x = x
        self.surface_y = surface_y      # y where the hook rests (boat level)
        self.max_depth = max_depth      # lowest y the hook can reach
        self.speed = speed              # pixels per second
        self.y = surface_y
        self.state = Hook.IDLE
        self.caught_fish = None

    @property
    def rect(self):
        return pygame.Rect(int(self.x - self.WIDTH // 2), int(self.y),
                           self.WIDTH, self.HEIGHT)

    def cast(self):
        """Task 3: start a cast only if idle; ignored while a cast is running."""
        if self.state == Hook.IDLE:
            self.state = Hook.CASTING
            return True
        return False

    def attach(self, fish):
        """Snag a fish and start heading back up."""
        self.caught_fish = fish
        self.state = Hook.RETRACTING

    def reset(self):
        self.y = self.surface_y
        self.state = Hook.IDLE
        self.caught_fish = None

    def update(self, dt):
        """Returns the fish that has just been brought to the surface (or None)."""
        landed = None
        if self.state == Hook.CASTING:
            self.y += self.speed * dt
            if self.y >= self.max_depth:
                self.y = self.max_depth
                self.state = Hook.RETRACTING
        elif self.state == Hook.RETRACTING:
            self.y -= self.speed * dt
            if self.y <= self.surface_y:
                self.y = self.surface_y
                self.state = Hook.IDLE
                landed, self.caught_fish = self.caught_fish, None

        # a snagged fish rides on the hook
        if self.caught_fish is not None:
            self.caught_fish.x = self.x - self.caught_fish.width / 2
            self.caught_fish.y = self.y
        return landed
