import random
import sys
import pygame

from game.hook import Hook
from game.fish import Fish, random_kind
from game.catch import check_catch
from game.renderer import Renderer

WIDTH, HEIGHT = 800, 600
WATER_Y = 150
FPS = 60
ROUND_SECONDS = 30
LANES = [230, 300, 370, 440, 510]       # fixed fish depths


class GameEngine:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Fishing Lab")
        self.clock = pygame.time.Clock()
        self.renderer = Renderer(self.screen, WATER_Y)
        self.hook = Hook(x=WIDTH // 2, surface_y=WATER_Y, max_depth=HEIGHT - 20)
        self.new_round()

    # ---------- round management (Task 4) ----------
    def new_round(self):
        self.score = 0
        self.time_left = float(ROUND_SECONDS)
        self.game_over = False
        self.hook.reset()
        self.fishes = [self.spawn_fish(y) for y in LANES for _ in range(2)]

    def spawn_fish(self, y):
        return Fish(random_kind(), random.randint(0, WIDTH), y,
                    random.choice([-1, 1]), WIDTH)

    # ---------- main loop ----------
    def handle_events(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if e.key == pygame.K_SPACE and not self.game_over:
                    self.hook.cast()                    # ignored if not idle (Task 3)
                if e.key == pygame.K_r and self.game_over:
                    self.new_round()

    def update(self, dt):
        if self.game_over:
            return

        self.time_left -= dt
        if self.time_left <= 0:
            self.time_left = 0
            self.game_over = True                       # no more catches / scoring
            return

        for f in self.fishes:
            f.update(dt)

        # snag a fish (only while the hook is travelling down and empty)
        if self.hook.state == Hook.CASTING and self.hook.caught_fish is None:
            for f in self.fishes:
                if check_catch(self.hook, f):
                    f.hooked = True
                    self.hook.attach(f)
                    break

        landed = self.hook.update(dt)
        if landed is not None:                          # fully back at surface
            self.score += landed.points
            lane_y = random.choice(LANES)
            self.fishes.remove(landed)
            self.fishes.append(self.spawn_fish(lane_y))

    def run(self):
        while True:
            dt = self.clock.tick(FPS) / 1000.0
            self.handle_events()
            self.update(dt)
            self.renderer.draw(self.hook, self.fishes, self.score, self.time_left,
                               self.game_over, WIDTH, HEIGHT)

