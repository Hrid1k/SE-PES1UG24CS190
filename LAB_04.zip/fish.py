import random
import pygame

# Task 2: fish types differ in speed, points, size and colour.
FISH_TYPES = {
    "minnow": {"speed": 70,  "points": 10, "size": (24, 12), "color": (150, 190, 230)},
    "bass":   {"speed": 130, "points": 25, "size": (38, 18), "color": (240, 140, 40)},
    "golden": {"speed": 220, "points": 50, "size": (30, 14), "color": (255, 215, 0)},
}
# Rarer = more valuable
TYPE_WEIGHTS = {"minnow": 5, "bass": 3, "golden": 1}


def random_kind():
    kinds = list(TYPE_WEIGHTS)
    return random.choices(kinds, weights=[TYPE_WEIGHTS[k] for k in kinds])[0]


class Fish:
    def __init__(self, kind, x, y, direction, screen_width):
        cfg = FISH_TYPES[kind]
        self.kind = kind
        self.speed = cfg["speed"]
        self.points = cfg["points"]
        self.width, self.height = cfg["size"]
        self.color = cfg["color"]
        self.x = x
        self.y = y
        self.direction = direction      # +1 right, -1 left
        self.screen_width = screen_width
        self.hooked = False

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.width, self.height)

    def update(self, dt):
        if self.hooked:
            return                      # position is driven by the hook
        self.x += self.direction * self.speed * dt
        if self.direction > 0 and self.x > self.screen_width:
            self.x = -self.width
        elif self.direction < 0 and self.x + self.width < 0:
            self.x = self.screen_width
